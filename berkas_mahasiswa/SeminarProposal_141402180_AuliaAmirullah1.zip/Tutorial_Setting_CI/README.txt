Program yang telah jadi dan telah disetting beserta database toko.sql ada pada folder Codeigniter-3.1.7 .

Jika anda ingin menjalankannya, letakkan folder Codeigniter-3.1.7 di XAMPP/htdocs.

Lalu Import toko.sql ke database server lokal anda.