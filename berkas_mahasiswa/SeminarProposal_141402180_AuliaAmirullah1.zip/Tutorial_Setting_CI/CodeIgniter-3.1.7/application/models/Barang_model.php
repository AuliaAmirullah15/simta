<?php

class Barang_model extends CI_Model {

private $primary_key='id';
private $table_name='barang';

function __construct() {
	parent::__construct();
}

function get_barang() {
	return $this->db->get($this->table_name);
}

function simpan_barang($data) {
    $this->db->insert($this->table_name,$data);
	return $this->db->insert_id();
}
    
function update_barang($id,$data) {
	$this->db->where($this->primary_key,$id);
	$this->db->update($this->table_name,$data);
}

function get_barang_by_id($id)
{
    $this->db->where($this->primary_key,$id);
	return $this->db->get($this->table_name);
}
    
function delete_barang($id)
{
    $this->db->where($this->primary_key,$id);
	$this->db->delete($this->table_name);
}
}