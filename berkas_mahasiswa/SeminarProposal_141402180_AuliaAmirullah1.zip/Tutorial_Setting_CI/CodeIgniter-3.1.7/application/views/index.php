<html>
    <head>
        <title>Beranda</title>
        
        <!-- BEGIN STYLESHEETS -->
		<link href='http://fonts.googleapis.com/css?family=Roboto:300italic,400italic,300,400,500,700,900' rel='stylesheet' type='text/css'/>
		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/custom.css');?>" />
		<!-- END STYLESHEETS -->
        
    <head>
    <body>
        <center>
            <h4>HALAMAN BERANDA</h4>
            <p>Tambah Barang Klik <?php echo anchor('Admin/tambah_barang', 'Di sini' ) ; ?></p>
            
            <?php if($message != '') {
                echo $message; 
} ?>
        <table border=1 cellpadding="5" cellspacing="0">
            <thead>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Stok</th>
                <th colspan="2">Action</th>
            </thead>
            <tbody>
                <?php if($data) {
                    //Jika ada data barang
                    $no = 1; 
    
                    foreach($data as $d)
                    { ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $d->nama ?></td>
                            <td><?= $d->harga ?></td>
                            <td><?= $d->stok ?></td>
                            <td><?php echo anchor('Admin/edit/'.$d->id, 'Edit') ;?></td>
                            <td><?php echo anchor('Admin/hapus/'.$d->id, 'Hapus') ;?></td>
                
                        </tr>
                   <?php }
                } else { echo "<td colspan='6'><center>Data Tidak Ditemukan</center></td>"; } ?>
            </tbody>
        </table>
        </center>
    </body>
</html>