<html>
    <head>
        <title><?= $title ?></title>
    </head>
    <?php 
        if($title == 'Tambah Barang')
        { 
            $var = 'tambah';
            $id = 0;
            $nama = '';
            $harga = '';
            $stok = '';
            $button = "Tambah";
        }
        else
        {
            $var = 'edit';
            $button = "Edit";
            foreach($data as $d)
            {
                $id = $d->id;
                $nama = $d->nama;
                $harga = $d->harga;
                $stok = $d->stok;
            }
        }
    ?>
    <body>
        <h4><?= $title ?></h4>
        <form method="post" action="<?php echo base_url().'Admin/proses/'.$id.'/'.$var;?>">
            <table>
                <tr>
                    <td>Nama Barang : </td>
                    <td><input type="text" name="nama" value="<?= $nama ?>"></td>
                </tr>
                <tr>
                    <td>Harga Barang : </td>
                    <td>Rp. <input type="number" name="harga" value="<?= $harga ?>"></td>
                </tr>
                
                <tr>
                    <td>Stok Barang : </td>
                    <td><input type="number" name="stok" value="<?= $stok ?>"></td>
                </tr>
                
                <tr>
                    <td colspan="2"><button type="submit"><?= $button ?></button></td>
                </tr>
            </table>
        
        </form>
    </body>
</html>