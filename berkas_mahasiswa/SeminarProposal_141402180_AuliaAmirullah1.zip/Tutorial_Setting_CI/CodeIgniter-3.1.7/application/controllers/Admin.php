<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    function __construct()
	{
		parent::__construct();
		#load library, model dan helper yang dibutuhkan
		$this->load->model('Barang_model','', TRUE); 
	}
	public function index()
	{
		//code anda 
        
        	
		if($this->uri->segment(3) == 'sukses_ditambah')
				$data['message'] = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'sukses_diedit')
				$data['message'] = 'Data berhasil diedit';
		else if($this->uri->segment(3) == 'sukses_menghapus')
				$data['message'] = 'Data berhasil dihapus';
		else
				$data['message'] ='';
        
        $data['data'] = $this->Barang_model->get_barang()->result();
        
        $this->load->view('index',$data);
	}
    
    public function tambah_barang()
    {
        $data['title'] = "Tambah Barang";
        $this->load->view('edit_barang',$data);
    }
    
    public function edit($id)
    {
        $data['title'] = "Edit Barang";
        $data['data'] = $this->Barang_model->get_barang_by_id($id)->result();
        
        $this->load->view('edit_barang',$data);
    }
    
    public function proses($id=null,$type)
    {
        $nama = $this->input->post('nama');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');
        
        $data = array(
                'nama' => $nama,
                'harga' => $harga,
                'stok' => $stok
            );
        
        if($type=="tambah")
        {
            $this->Barang_model->simpan_barang($data);
            
            redirect('Admin/index/sukses_ditambah');
        }
        
        else
        {
            $this->Barang_model->update_barang($id,$data);
            
            redirect('Admin/index/sukses_diedit');
        }
    }
    
    public function hapus($id)
    {
        $this->Barang_model->delete_barang($id);
        
        redirect('Admin/index/sukses_menghapus');
    }
    
}
