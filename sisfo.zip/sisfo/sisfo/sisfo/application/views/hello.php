<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Hello Codeigniter</title>

	

</head>
<body>

<div id="container">
	<h1>Hello Codeigniter</h1>
	Back to welcome.php --> controllers/welcome.php set be welcome_message
 
</div>

</body>
</html>