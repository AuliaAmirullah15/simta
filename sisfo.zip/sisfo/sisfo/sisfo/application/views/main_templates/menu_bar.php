<div id="menubar" class="menubar-inverse ">
				<div class="menubar-fixed-panel">
					<div>
						<a class="btn btn-icon-toggle btn-default menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
							<i class="fa fa-bars"></i>
						</a>
					</div>
					<div class="expanded">
						<a href="../../html/dashboards/dashboard.html">
							<span class="text-lg text-bold text-primary ">SISFO-TA</span>
						</a>
					</div>
				</div>
				<div class="menubar-scroll-panel">

					<!-- BEGIN MAIN MENU -->
					<ul id="main-menu" class="gui-controls">
					<?php if($_SESSION['level'] == '1') {?>
						<!-- BEGIN TABLES -->
						<!--MANAGE TA MENU-->
						<li class="gui-folder">
							<a>
								<div class="gui-icon"><i class="fa fa-table"></i></div>
								<span class="title">Manage TA</span>
							</a>
							<!--start submenu -->

							<ul>
								<li><a href="<?php echo base_url().'tugas/disertasi';?>" <?php if($active == 'disertasi') { echo "class='active'"; }?>><span class="title">Disertasi</span></a></li>
								<li><a href="<?php echo base_url().'tugas/skripsi';?>" <?php if($active == 'skripsi') { echo "class='active'"; }?> ><span class="title">Skripsi</span></a></li>
								<li><a href="<?php echo base_url().'tugas/tesis';?>" <?php if($active == 'tesis') { echo "class='active'"; }?>><span class="title">Tesis</span></a></li>
							
							</ul><!--end /submenu -->
						</li><!--end /menu-li -->
						<!-- END MANAGE TA MENU -->

						<!-- DOSEN MENU-->
						<li>
							<a href="<?php echo base_url().'tugas/index';?>" <?php if($active == 'dosen') { echo "class='active'"; }?>>
								<div class="gui-icon"><i class="glyphicon glyphicon-user"></i></div>
								<span class="title">Dosen</span>
							</a>
						</li>


						<!-- END DOSEN MENU -->

						<!-- PRODI MENU-->
						<li>
							<a href="<?php echo base_url().'tugas/prodi';?>" <?php if($active == 'prodi') { echo "class='active'"; }?>>
								<div class="gui-icon"><i class="glyphicon glyphicon-th"></i></div>
								<span class="title">Program Studi</span>
							</a>
						</li>


						<!-- END PRODI MENU -->


						<!-- GAJI DOSEN SEMINAR MENU-->
						<li>
							<a href="<?php echo base_url().'tugas/gaji_dosen';?>" <?php if($active == 'gaji') {
								echo "class='active'";} ?> >
								<div class="gui-icon"><i class="glyphicon glyphicon-usd"></i></div>
								<span class="title">Gaji Dosen Seminar</span>
							</a>
						</li>


						<!-- END GAJI DOSEN SEMINAR MENU -->

						<!-- GAJI DOSEN SEMINAR MENU-->
						<li>
							<a href="<?php echo base_url().'tugas/jadwal_seminar';?>" <?php if($active == 'jadwal seminar') {
								echo "class='active'";} ?> >
								<div class="gui-icon"><i class="glyphicon glyphicon-time"></i></div>
								<span class="title">Jadwal Seminar</span>
							</a>
						</li>


						<!-- END GAJI DOSEN SEMINAR MENU -->

						<!-- SEARCHING MENU-->
						<li>
							<a href="<?php echo base_url().'tugas/search_mahasiswa';?>" <?php if($active == 'pencarian_mahasiswa') {
								echo "class='active'";} ?> >
								<div class="gui-icon"><i class="glyphicon glyphicon-search"></i></div>
								<span class="title">Pencarian</span>
							</a>
						</li>


						<!-- END SEARCHING MENU -->
						

						<!--MANAGE TA MENU-->
						<li class="gui-folder">
							<a>
								<div class="gui-icon"><i class="fa fa-table"></i></div>
								<span class="title">Pencatatan Skripsi</span>
							</a>
							<!--start submenu -->

							<ul>
								<li><a href="<?php echo base_url().'tugas/tambah_skripsi';?>" <?php if($active == 'tambah_skripsi') {echo "class='active'";} ?> ><span class="title">Pencatatan</span></a></li>
								<li><a href="<?php echo base_url().'tugas/log_pencatatan';?>" <?php if($active == 'log_pencatatan') { echo "class='active'"; }?>><span class="title">Log Pencatatan</span></a></li>
							</ul><!--end /submenu -->
						</li><!--end /menu-li -->
						<!-- END MANAGE TA MENU -->
						<!-- END TABLES -->
						<?php } ?>

						<?php if($_SESSION['level'] == '3') { ?>
						<li class="gui-folder">
							<a>
								<div class="gui-icon"><span class="glyphicon glyphicon-list-alt"></span></div>
								<span class="title">Form</span>
							</a>
							<!--start submenu -->
							<ul>
								<li><a href="<?php echo base_url().'tugas/get_assesment/'.$_SESSION['id_skripsi'];?>" ><span class="title">Assesment</span></a></li>
								<li><a href="#" ><span class="title">Sidang</span></a></li>
							
							</ul><!--end /submenu -->
						</li><!--end /menu-li -->
						<!-- END FORMS -->

						<!-- END LEVELS -->
						<?php } ?>
					</ul><!--end .main-menu -->
					<!-- END MAIN MENU -->

					<div class="menubar-foot-panel">
						<small class="no-linebreak hidden-folded">
							<span class="opacity-75">Copyright &copy; 2014</span> <strong>CodeCovers</strong>
						</small>
					</div>
				</div><!--end .menubar-scroll-panel-->
			</div><!--end #menubar-->