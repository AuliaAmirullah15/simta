<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class Tugas extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		#load library dan helper yang dibutuhkan
		$this->load->library(array('form_validation'));
		$this->load->helper(array('url','form'));
		$this->load->library('session');
		$this->load->model('dosen_model','',TRUE);	
		$this->load->model('disertasi_model','',TRUE);	
		$this->load->model('skripsi_model','',TRUE);
		$this->load->model('cari_model','',TRUE);	
		$this->load->model('tesis_model','',TRUE);	
		$this->load->model('prodi_model','',TRUE);	
		$this->load->model('formulir_model','',TRUE);	
		$this->load->model('gaji_model','',TRUE);	
		$this->load->model('jadwal_model','', TRUE); 
		$this->load->model('pencatatan_model','', TRUE); 
		$this->load->library('pagination');
		$this->load->model('login_model','login',true);
	}

		public function getGlobal($id)
		{
			return [
				'jumlah_mhs_sem' => (int) @$this->db->query("SELECT COUNT(*) as jumlah_mhs FROM mahasiswa_sidang WHERE id_jadwal_seminar = {$id}")
				 ->row()
				 ->jumlah_mhs ?: 0,
				'batas_mhs_sem' => (int) @$this->db->query("SELECT * FROM jadwal_seminar WHERE id = {$id}")
				 ->row()
				 ->batas_sidang ?: 0
			];
		}

		function index()
		{

			
		$data['user']=$this->dosen_model->get_paged_list()->result();
		$this->load->library('pagination');
		$config['uri_segment']=3;
		$this->pagination->initialize($config);
		
		if($this->uri->segment(3) == 'delete_success')
				$data['message'] = 'Data berhasil dihapus';
		else if($this->uri->segment(3) == 'add_success')
				$data['message'] = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'update_success')
				$data['message'] = 'Data berhasil diedit';
		else
				$data['message'] =' ';

		$data['active'] = 'dosen';
		$this->load->view('templates/dosen',$data);

		}


		//validation rules

		function _set_rules() {
	
			$this->form_validation->set_rules('Kode_dosen','kd_dosen',
			'required');
		}
		function add_dosen()
		{

		$data['prodi']=$this->prodi_model->get_paged_list()->result();
		$data['active'] ='dosen';

		$this->load->view('templates/insert_dosen',$data);
	
		}

		function insert_adv(){
		$kd = $this->input->post('Kode_dosen');
		$nama = $this->input->post('Nama_dosen');
		$pangkat = $this->input->post('Pangkat');
		$golongan = $this->input->post('Golongan');
		$nip = $this->input->post('NIP');
		$nidn = $this->input->post('NIDN');
		$kode = $this->input->post('Kode_PS');

		$data = array(
			'Kode_dosen' => $kd,
			'Nama_dosen' => $nama,
			'Pangkat' => $pangkat,
			'Golongan' => $golongan,
			'NIP' => $nip,
			'NIDN' => $nidn,
			'Kode_PS' => $kode
			);
		$this->dosen_model->save($data);
		redirect('tugas/index/add_success',$data);
	}

		function update($id)
		{
			$data['studi']=$this->prodi_model->get_paged_list()->result();
			$data['dosen']=$this->dosen_model->get_paged_list_update($id)->result();
			$data['active'] = 'dosen';
			$this->load->view('templates/edit_dosen',$data);
		}

		function update_dsn($id)
		{

		$id = $id;
		$kd = $this->input->post('Kode_dosen');
		$nama = $this->input->post('Nama_dosen');
		$pangkat = $this->input->post('Pangkat');
		$golongan = $this->input->post('Golongan');
		$nip = $this->input->post('NIP');
		$nidn = $this->input->post('NIDN');
		$kode = $this->input->post('Kode_PS');
		var_dump($kd);
		$data = array(
			'Kode_dosen' => $kd,
			'Nama_dosen' => $nama,
			'Pangkat' => $pangkat,
			'Golongan' => $golongan,
			'NIP' => $nip,
			'NIDN' => $nidn,
			'Kode_PS' => $kode
			);

		$this->dosen_model->update($id,$data);
		redirect ('tugas/index/update_success');
		}



	function delete_dosen($id) {
	//delete siswa
	$this->dosen_model->delete($id);

	//redirect to dosen list page
	
	redirect('tugas/index/delete_success','refresh');
}

	function search_mahasiswa()
	{
		$data['active']='pencarian_mahasiswa';
		$data['data'] = $this->cari_model->cari_mahasiswa2()->result();
		$data['jumlah'] = $this->cari_model->cari_mahasiswa2()->num_rows();
		$this->load->view('templates/pencarian_mahasiswa',$data);
	}


	function proses_cari_mahasiswa()
	{
		$key = $this->input->post('key');
		$status1 = $this->input->post('status_pemb');
		$status2 = $this->input->post('status');

		$data['data'] = $this->cari_model->cari_mahasiswa($key,$status1,$status2)->result();
		$data['jumlah'] = $this->cari_model->cari_mahasiswa($key,$status1,$status2)->num_rows();

		$this->load->view('templates/pencarian_mahasiswa',$data);
	}
		function disertasi($page=null)
		{
			$this->load->database();
			$this->load->library('pagination');
			//load data siswa
			$disertasi['batas'] = $this->input->post('batas');

			if($disertasi['batas'] == NULL)
				{$halaman = 5;}
			else
			{
				$halaman = $disertasi['batas'];
			}

			$off = $page;

		$disertasi['data']=$this->disertasi_model->get_paged_list($halaman,$off)->result();
		$disertasi['jumlah'] = $this->disertasi_model->get_paged_list_count()->num_rows();
		$disertasi['studi'] = $this->prodi_model->get_paged_list()->result();
		

				$config['base_url'] = base_url().'tugas/disertasi';
				$config['total_rows'] = $disertasi['jumlah'];
				$config['per_page'] = $halaman;
				$config['prev_tag_open'] = "<div class='previous'>";
				$config['prev_tag_close'] = "</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_tag_close'] ="</div>";
				$config['prev_tag_open'] = "<div class='btn btn-default' >";
				$config['prev_tag_close'] ="</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_link'] = "Next";
				$config['prev_link'] = "Prev";
				$config['first_link'] = false;
				$config['last_link'] = false;
				$config['display_pages'] = false;

				
				$this->pagination->initialize($config);

				$disertasi['pagination'] = $this->pagination->create_links();
		if($this->uri->segment(3) == 'delete_success')
				$disertasi['message'] = 'Data berhasil dihapus';
		else if($this->uri->segment(3) == 'add_success')
				$disertasi['message'] = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'update_success')
				$disertasi['message'] = 'Data berhasil diedit';
		else
				$disertasi['message'] =' ';

			$disertasi['no'] = 1+$off;
			$disertasi['active'] = 'disertasi';

		$this->load->view('templates/disertasi',$disertasi);

		}

		function search_disertasi($offset = null)
		{
			$this->load->database();
			$this->load->library('pagination');

			
			$halaman = 30;
			$off = $offset;
			$data['set'] = 1;
		
			$data['cari'] = $this->input->post('key');
			$data['tgl_mulai'] = $this->input->post('tgl_awal');
			$data['tgl_akhir'] = $this->input->post('tgl_akhir');
			$data['pil'] = $this->input->post('pilihan');
			$data['skripsi'] = $this->input->post('skripsi');
			$data['nim'] = $this->input->post('nim');
			$data['prodi'] = $this->input->post('prodi');
			$data['reset'] = $this->input->post('reset');


			//set NULL value
			//if($data['prodi'] == 'all') {$data['prodi'] = NULL;}
			//var_dump($data); die();
			$data['data'] = $this->cari_model->cariin($data['skripsi'],$data['nim'],$data['prodi'],$data['cari'],$data['tgl_mulai'],$data['tgl_akhir'],$data['pil'],$halaman,$off,'v_disertasi')->result();

			
			//var_dump($db);
			$data['jumlah'] = $this->cari_model->jumlah_cariin($data['skripsi'],$data['nim'],$data['prodi'],$data['cari'],$data['tgl_mulai'],$data['tgl_akhir'],$data['pil'],'v_disertasi')->num_rows();
			$data['studi'] = $this->prodi_model->get_paged_list()->result();

				$config['base_url'] = base_url().'tugas/search_skripsi';
				$config['total_rows'] = $data['jumlah']; 
				$config['per_page'] = $halaman;
				$config['uri_segment'] = 3;
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_tag_close'] ="</div>";
				$config['prev_tag_open'] = "<div class='btn btn-default' >";
				$config['prev_tag_close'] ="</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_link'] = "Next";
				$config['prev_link'] = "Prev";
				$config['first_link'] = false;
				$config['last_link'] = false;
				$config['display_pages'] = false;
				$this->pagination->initialize($config);

				$data['pagination'] = $this->pagination->create_links();

			if($this->uri->segment(3) == 'delete_success')
				$message = 'Data berhasil dihapus';
		else if($this->uri->segment(3) == 'add_success')
				$message = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'update_success')
				$message = 'Data berhasil diedit';
		else
				$message =' ';
		$data['no'] = 1+$off;
		
		$this->load->view('templates/disertasi',$data);

		}

		function add_disertasi()
		{	
		$data['prodi'] = $this->prodi_model->get_paged_list()->result();
		$data['dosen'] = $this->dosen_model->get_paged_list()->result();
		$data['active'] = 'disertasi';
		$this->load->view('templates/insert_disertasi',$data);
		}

		function insert_disertasi(){
		$kd = $this->input->post('id_disertasi');
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$kode = $this->input->post('kode_PS');
		$judul = $this->input->post('judul_skripsi');
		$pembimbing1 = $this->input->post('kode_pembimbing1');
		$pembimbing2 = $this->input->post('kode_pembimbing2');
		$tgl = date('Y-m-d',
	strtotime($this->input->post('Tgl_lulus')));
		

		$data = array(
			'id_disertasi' => $kd,
			'nim' => $nim,
			'nama' => $nama,
			'kode_PS' => $kode,
			'judul_skripsi' => $judul,
			'kode_pembimbing1' => $pembimbing1,
			'kode_pembimbing2' => $pembimbing2,
			'Tgl_lulus' => $tgl,
			);
		$this->disertasi_model->save($data);
		$disertasi['active'] = 'disertasi';
		redirect('tugas/disertasi/add_success', $disertasi);
	}


	function delete_disertasi($id) {
	//delete siswa
	$this->disertasi_model->delete($id);

	/*echo "

<script>
function confirmDialog($nama) {
 return confirm('Apakah anda yakin akan menghapus data ini?')
}
</script>

";*/
	//redirect to dosen list page
	
	redirect('tugas/disertasi/delete_success','refresh');
}


		function update_disertasi($id)
		{
			$data['prodi2'] = $this->prodi_model->get_paged_list()->result();
			$data['disertasi']=$this->disertasi_model->get_paged_list_update($id)->result();
			$data['dosen'] = $this->dosen_model->get_paged_list()->result();
			$data['active'] = 'disertasi';
			$this->load->view('templates/edit_disertasi',$data);

		}

		function update_dis()
		{
		$id = $this->input->post('id_disertasi');
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$prodi = $this->input->post('kode_PS');
		$judul = $this->input->post('judul_skripsi');
		$pembimbing1 = $this->input->post('kode_pembimbing1');
		$pembimbing2 = $this->input->post('kode_pembimbing2');
		$tgl = date('Y-m-d',strtotime($this->input->post('Tgl_lulus')));

			
		$data = array(
			'id_disertasi' => $id,
			'nim' => $nim,
			'nama' => $nama,
			'kode_PS' => $prodi,
			'judul_skripsi' => $judul,
			'kode_pembimbing1' => $pembimbing1,
			'kode_pembimbing2' => $pembimbing2,
			'Tgl_lulus' => $tgl
			);
	
		$this->disertasi_model->update($id,$data);
		redirect ('tugas/disertasi/update_success');
		}

		function skripsi($page = null)
		{
			$this->load->database();
			$this->load->library('pagination');

			$data['batas'] = $this->input->post('batas');

			if($data['batas'] == NULL)
				{$halaman = 5;}
			else
			{
				$halaman = $data['batas'];
			}

			$off = $page;
				
				$data['data'] =$this->skripsi_model->get_paged_list($halaman,$off)->result();
				$data['jumlah'] = $this->skripsi_model->get_paged_list_count()->num_rows();
				$data['studi'] = $this->prodi_model->get_paged_list()->result();

				$config['base_url'] = base_url().'tugas/skripsi';
				$config['total_rows'] = $data['jumlah'];
				$config['per_page'] = $halaman;
				$config['prev_tag_open'] = "<div class='previous'>";
				$config['prev_tag_close'] = "</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_tag_close'] ="</div>";
				$config['prev_tag_open'] = "<div class='btn btn-default' >";
				$config['prev_tag_close'] ="</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_link'] = "Next";
				$config['prev_link'] = "Prev";
				$config['first_link'] = false;
				$config['last_link'] = false;
				$config['display_pages'] = false;

				
				$this->pagination->initialize($config);

				$data['pagination'] = $this->pagination->create_links();
			if($this->uri->segment(3) == 'delete_success')
				$data['message'] = 'Data berhasil dihapus';
		else if($this->uri->segment(3) == 'add_success')
				$data['message'] = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'update_success')
				$data['message'] = 'Data berhasil diedit';
		else
				$data['message'] =' ';
		$data['no'] = 1+$off;
		$data['active'] = 'skripsi';
		$this->load->view('templates/skripsi',$data);
		}

		function search_skripsi($offset = null)
		{
			$this->load->database();
			$this->load->library('pagination');

			$halaman = 5;
			$off = $offset;
			$data['set'] = 1;
		
			$data['cari'] = $this->input->post('key');
			$data['tahun_lulus'] = $this->input->post('tahun_lulus');
			$data['tahun_lulus2'] = $this->input->post('tahun_lulus2');
			$data['skripsi'] = $this->input->post('skripsi');
			$data['nim'] = $this->input->post('nim');
			$data['prodi'] = $this->input->post('prodi');
			$data['reset'] = $this->input->post('reset');
			$data['batas'] = $this->input->post('batas');
			//set NULL value
			//if($data['prodi'] == 'all') {$data['prodi'] = NULL;}
			//var_dump($data); die();
			//$halaman = $data['batas'];
			
			$data['data'] = $this->cari_model->cariin($data['skripsi'],$data['nim'],$data['prodi'],$data['cari'],$data['tahun_lulus'],$data['tahun_lulus2'],$halaman,$off,'v_pencatatan')->result();

			
			//var_dump($db);
			$data['jumlah'] = $this->cari_model->jumlah_cariin($data['skripsi'],$data['nim'],$data['prodi'],$data['cari'],$data['tahun_lulus'],$data['tahun_lulus2'], 'v_pencatatan')->num_rows();
			$data['studi'] = $this->prodi_model->get_paged_list()->result();

				$config['base_url'] = base_url().'tugas/search_skripsi';
				$config['total_rows'] = $data['jumlah']; 
				$config['per_page'] = $halaman;
				$config['uri_segment'] = 3;
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_tag_close'] ="</div>";
				$config['prev_tag_open'] = "<div class='btn btn-default' >";
				$config['prev_tag_close'] ="</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_link'] = "Next";
				$config['prev_link'] = "Prev";
				$config['first_link'] = false;
				$config['last_link'] = false;
				$config['display_pages'] = false;
				$this->pagination->initialize($config);

				$data['pagination'] = $this->pagination->create_links();

			if($this->uri->segment(3) == 'delete_success')
				$message = 'Data berhasil dihapus';
		else if($this->uri->segment(3) == 'add_success')
				$message = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'update_success')
				$message = 'Data berhasil diedit';
		else
				$message =' ';
		$data['no'] = 1+$off;
		$data['active'] = 'skripsi';
		$this->load->view('templates/skripsi',$data);

		}
		
		function add_skripsi()
		{

		$data['prodi'] = $this->prodi_model->get_paged_list()->result();
		$data['pembimbing'] = $this->dosen_model->get_paged_list()->result();
		$data['active'] = 'skripsi';
		$this->load->view('templates/insert_skripsi', $data);
		
	
		}

		function insert_skripsi(){
		$kd = $this->input->post('id_skripsi');
		$judul = $this->input->post('judul_skripsi');
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$kode = $this->input->post('kode_PS');
		$pembimbing1 = $this->input->post('kode_Pembimbing1');
		$pembimbing2 = $this->input->post('kode_Pembimbing2');
		$tgl = date('Y-m-d',
	strtotime($this->input->post('Tgl_lulus')));
		

		$data = array(
			'id_skripsi' => $kd,
			'judul_skripsi' => $judul,
			'nim' => $nim,
			'nama' => $nama,
			'kode_PS' => $kode,
			'kode_Pembimbing1' => $pembimbing1,
			'kode_Pembimbing2' => $pembimbing2,
			'Tgl_lulus' => $tgl
			);
		$this->skripsi_model->save($data);
		redirect('tugas/skripsi/add_success');
	}

	function tambah_skripsi()
		{
			$data['prodi'] = $this->prodi_model->get_paged_list()->result();
			$data['pembimbing'] = $this->dosen_model->get_paged_list()->result();
			$data['active'] = 'skripsi';

			if($this->uri->segment(3) == 'add_success')
				$data['message'] = 'Data berhasil ditambah';
			$data['active'] ='tambah_skripsi';

			$this->load->view('templates/tambah_skripsi', $data);
		}

	function proses_tambah_skripsi()
	{
		$nim = $this->input->post('nim');
		$tahun_lulus = $this->input->post('tahun_lulus');
		$kode_PS = $this->input->post('kode_PS');
		$sk_pembimbing = $this->input->post('sk_pembimbing');
		$sk_pembanding = $this->input->post('sk_pembanding');
		$nama = $this->input->post('nama');
		$judul= $this->input->post('judul');
		$kode_Pembimbing1 = $this->input->post('kode_Pembimbing1');
		$kode_Pembimbing2 = $this->input->post('kode_Pembimbing2');
		$kode_Pembanding1 = $this->input->post('kode_Pembanding1');
		$kode_Pembanding2 = $this->input->post('kode_Pembanding2');
		$tgl_sempro = $this->input->post('tgl_sempro');
		$tgl_semhas = $this->input->post('tgl_semhas');
		$tgl_sidang = $this->input->post('tgl_sidang');
		$uji_program = $this->input->post('nilai_uji_program');
		$nilai_semhas = $this->input->post('nilai_semhas');
		$nilai_sidang = $this->input->post('nilai_sidang');
		$total = $this->input->post('total');
		$grade = $this->input->post('grade');
		$status = $this->input->post('status');
		$mahasiswa = array (
				'nim' => $nim,
				'nama' => $nama,
				'id_PS' => $kode_PS,
				'status' => $status
			);

		$pembimbing = array(
				'nomor_sk' => $sk_pembimbing,
				'nim' => $nim,
				'pembimbing1' => $kode_Pembimbing1,
				'pembimbing2' => $kode_Pembimbing2
			);

		$pembanding = array(
				'nomor_sk' => $sk_pembanding,
				'nim' => $nim,
				'pembanding1' => $kode_Pembanding1,
				'pembanding2' => $kode_Pembanding2
			);

		$nilai = array(
				'nim' => $nim,
				'nilai_uji_program' => $uji_program,
				'nilai_semhas' => $nilai_semhas,
				'nilai_sidang' => $nilai_sidang,
				'total' => $total,
				'grade' => $grade
			);

		$skripsi = array(
				'nim' => $nim,
				'judul' => $judul,
				'tahun_lulus' =>$tahun_lulus,
				'tanggal_sempro' =>$tgl_sempro,
				'tanggal_semhas' => $tgl_semhas,
				'tanggal_sidang' => $tgl_sidang
			);

		$this->pencatatan_model->save_mahasiswa($mahasiswa);
		$this->pencatatan_model->save_pembimbing($pembimbing);
		$this->pencatatan_model->save_pembanding($pembanding);
		$this->pencatatan_model->save_nilai($nilai);
		$this->pencatatan_model->save_skripsi($skripsi);
		
		redirect('tugas/tambah_skripsi/add_success');
	}

	function log_pencatatan()
	{
		$data['active'] = 'log_pencatatan';
		$data['data'] = $this->pencatatan_model->get_data_pencatatan()->result();
		$this->load->view('templates/log_pencatatan', $data);
	}

	function detail_skripsi($nim)
	{
		$data['data']=$this->skripsi_model->get_data($nim)->result();
		$this->load->view('templates/detail_skripsi', $data);
	}
	function delete_skripsi($nim) {
	//delete siswa
	$this->skripsi_model->delete_mahasiswa($nim);
	$this->skripsi_model->delete_pembimbing($nim);
	$this->skripsi_model->delete_pembanding($nim);
	$this->skripsi_model->delete_skripsi($nim);
	$this->skripsi_model->delete_nilai($nim);

	
	redirect('tugas/skripsi/delete_success','refresh');
}

	function update_skripsi($id)
		{
			$data['skripsi']=$this->skripsi_model->get_paged_list_update($id)->result();
			$data['prodi'] = $this->prodi_model->get_paged_list()->result();
			$data['pembimbing'] = $this->dosen_model->get_paged_list()->result();
			$data['tgl'] = $this->skripsi_model->get_date($id)->result();
			$data['active'] = 'skripsi';
			$this->load->view('templates/edit_skripsi',$data);
		}

		function update_skr()
		{
			$nim = $this->input->post('nim');
		$tahun_lulus = $this->input->post('tahun_lulus');
		$kode_PS = $this->input->post('kode_PS');
		$sk_pembimbing = $this->input->post('sk_pembimbing');
		$sk_pembanding = $this->input->post('sk_pembanding');
		$nama = $this->input->post('nama');
		$judul= $this->input->post('judul');
		$kode_Pembimbing1 = $this->input->post('kode_Pembimbing1');
		$kode_Pembimbing2 = $this->input->post('kode_Pembimbing2');
		$kode_Pembanding1 = $this->input->post('kode_Pembanding1');
		$kode_Pembanding2 = $this->input->post('kode_Pembanding2');
		$tgl_sempro = $this->input->post('tgl_sempro');
		$tgl_semhas = $this->input->post('tgl_semhas');
		$tgl_sidang = $this->input->post('tgl_sidang');
		$uji_program = $this->input->post('nilai_uji_program');
		$nilai_semhas = $this->input->post('nilai_semhas');
		$nilai_sidang = $this->input->post('nilai_sidang');
		$total = $this->input->post('total');
		$grade = $this->input->post('grade');

		$mahasiswa = array (
				'nim' => $nim,
				'nama' => $nama,
				'id_PS' => $kode_PS
			);

		$pembimbing = array(
				'nomor_sk' => $sk_pembimbing,
				'nim' => $nim,
				'pembimbing1' => $kode_Pembimbing1,
				'pembimbing2' => $kode_Pembimbing2
			);

		$pembanding = array(
				'nomor_sk' => $sk_pembanding,
				'nim' => $nim,
				'pembanding1' => $kode_Pembanding1,
				'pembanding2' => $kode_Pembanding2
			);

		$nilai = array(
				'nim' => $nim,
				'nilai_uji_program' => $uji_program,
				'nilai_semhas' => $nilai_semhas,
				'nilai_sidang' => $nilai_sidang,
				'total' => $total,
				'grade' => $grade
			);

		$skripsi = array(
				'nim' => $nim,
				'judul' => $judul,
				'tahun_lulus' =>$tahun_lulus,
				'tanggal_sempro' =>$tgl_sempro,
				'tanggal_semhas' => $tgl_semhas,
				'tanggal_sidang' => $tgl_sidang
			);

	
		$this->skripsi_model->update_mahasiswa($nim,$mahasiswa);
		$this->skripsi_model->update_pembimbing($nim,$pembimbing);
		$this->skripsi_model->update_pembanding($nim,$pembanding);
		$this->skripsi_model->update_nilai($nim,$pembanding);
		$this->skripsi_model->update_skripsi($nim,$skripsi);
		redirect ('tugas/skripsi/update_success');
		}

		function tesis($page = null)
		{

			$this->load->database();
			$this->load->library('pagination');


			$tesis['batas'] = $this->input->post('batas');

			if($tesis['batas'] == NULL)
				{$halaman = 5;}
			else
			{
				$halaman = $tesis['batas'];
			}

			$off = $page;


			//load data siswa
		$tesis['data']=$this->tesis_model->get_paged_list($halaman,$off)->result();
		$tesis['jumlah']=$this->tesis_model->get_paged_list_count()->num_rows();

		$tesis['studi'] = $this->prodi_model->get_paged_list()->result();

				$config['base_url'] = base_url().'tugas/tesis';
				$config['total_rows'] = $tesis['jumlah'];
				$config['per_page'] = $halaman;
				$config['prev_tag_open'] = "<div class='previous'>";
				$config['prev_tag_close'] = "</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_tag_close'] ="</div>";
				$config['prev_tag_open'] = "<div class='btn btn-default' >";
				$config['prev_tag_close'] ="</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_link'] = "Next";
				$config['prev_link'] = "Prev";
				$config['first_link'] = false;
				$config['last_link'] = false;
				$config['display_pages'] = false;

		$this->pagination->initialize($config);
		$tesis['pagination'] = $this->pagination->create_links();
		
		if($this->uri->segment(3) == 'delete_success')
				$tesis['message'] = 'Data berhasil dihapus';
		else if($this->uri->segment(3) == 'add_success')
				$tesis['message'] = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'update_success')
				$tesis['message'] = 'Data berhasil diedit';
		else
				$tesis['message'] =' ';

		$tesis['no']=1+$off;
		$tesis['active'] = 'tesis';
		$this->load->view('templates/tesis',$tesis);

		}

		function search_tesis($offset = null)
		{
			$this->load->database();
			$this->load->library('pagination');

			
			$halaman = 30;
			$off = $offset;
			$data['set'] = 1;
		
			$data['cari'] = $this->input->post('key');
			$data['tgl_mulai'] = $this->input->post('tgl_awal');
			$data['tgl_akhir'] = $this->input->post('tgl_akhir');
			$data['pil'] = $this->input->post('pilihan');
			$data['skripsi'] = $this->input->post('skripsi');
			$data['nim'] = $this->input->post('nim');
			$data['prodi'] = $this->input->post('prodi');
			$data['reset'] = $this->input->post('reset');


			//set NULL value
			//if($data['prodi'] == 'all') {$data['prodi'] = NULL;}
			//var_dump($data); die();
			$data['data'] = $this->cari_model->cariin($data['skripsi'],$data['nim'],$data['prodi'],$data['cari'],$data['tgl_mulai'],$data['tgl_akhir'],$data['pil'],$halaman,$off,'v_tesis')->result();

			
			//var_dump($db);
			$data['jumlah'] = $this->cari_model->jumlah_cariin($data['skripsi'],$data['nim'],$data['prodi'],$data['cari'],$data['tgl_mulai'],$data['tgl_akhir'],$data['pil'], 'v_tesis')->num_rows();
			$data['studi'] = $this->prodi_model->get_paged_list()->result();

				$config['base_url'] = base_url().'tugas/search_tesis';
				$config['total_rows'] = $data['jumlah']; 
				$config['per_page'] = $halaman;
				$config['uri_segment'] = 3;
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_tag_close'] ="</div>";
				$config['prev_tag_open'] = "<div class='btn btn-default' >";
				$config['prev_tag_close'] ="</div>";
				$config['next_tag_open'] = "<div class='btn btn-default' >";
				$config['next_link'] = "Next";
				$config['prev_link'] = "Prev";
				$config['first_link'] = false;
				$config['last_link'] = false;
				$config['display_pages'] = false;
				$this->pagination->initialize($config);

				$data['pagination'] = $this->pagination->create_links();

			if($this->uri->segment(3) == 'delete_success')
				$message = 'Data berhasil dihapus';
		else if($this->uri->segment(3) == 'add_success')
				$message = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'update_success')
				$message = 'Data berhasil diedit';
		else
				$message =' ';
		$data['no'] = 1+$off;
		$data['active'] = 'tesis';
		$this->load->view('templates/tesis',$data);

		}

		function add_tesis()
		{
		$data['prodi'] = $this->prodi_model->get_paged_list()->result();
		$data['pembimbing'] = $this->dosen_model->get_paged_list()->result();
		$data['active'] ='tesis';
		$this->load->view('templates/insert_tesis', $data);
		
	
		}

		function insert_tesis(){
		$kd = $this->input->post('id_tesis');
		$judul = $this->input->post('judul_skripsi');
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama_mhs');
		$kode = $this->input->post('kode_PS');
		$pembimbing1 = $this->input->post('kode_pembimbing1');
		$pembimbing2 = $this->input->post('kode_pembimbing2');
		$tgl = date('Y-m-d',
			strtotime($this->input->post('Tgl_lulus')));
		

		$data = array(
			'id_tesis' => $kd,
			'judul_skripsi' => $judul,
			'nim' => $nim,
			'nama_mhs' => $nama,
			'kode_PS' => $kode,
			'kode_pembimbing1' => $pembimbing1,
			'kode_pembimbing2' => $pembimbing2,
			'Tgl_lulus' => $tgl
			);
		$this->tesis_model->save($data);
		redirect('tugas/tesis/add_success');
	}

	function delete_tesis($id) {
	//delete siswa
	$this->tesis_model->delete($id);

	/*echo "

<script>
function confirmDialog($nama) {
 return confirm('Apakah anda yakin akan menghapus data ini?')
}
</script>

";*/
	//redirect to dosen list page
	
	redirect('tugas/tesis/delete_success','refresh');
}

	function update_tesis($id)
		{
			$data['dosen']=$this->dosen_model->get_paged_list()->result();
			$data['prodi2']=$this->prodi_model->get_paged_list()->result();
			$data['tesis']=$this->tesis_model->get_paged_list_update($id)->result();
			$data['active'] = 'tesis';
			$this->load->view('templates/edit_tesis',$data);

		}

	function update_tes()
		{
		$id = $this->input->post('id_tesis');
		$judul = $this->input->post('judul_skripsi');
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama_mhs');
		$prodi = $this->input->post('kode_PS');
		$pembimbing1 = $this->input->post('kode_pembimbing1');
		$pembimbing2 = $this->input->post('kode_pembimbing2');
		$tgl = date('Y-m-d',strtotime($this->input->post('Tgl_lulus')));

			
		$data = array(
			'id_tesis' => $id,
			'judul_skripsi' => $judul,
			'nim' => $nim,
			'nama_mhs' => $nama,
			'kode_PS' => $prodi,
			'kode_pembimbing1' => $pembimbing1,
			'kode_pembimbing2' => $pembimbing2,
			'Tgl_lulus' => $tgl
			);
	
		$this->tesis_model->update($id,$data);
		redirect ('tugas/tesis/update_success');
		}

	function prodi()
		{

			//load data siswa
		$prodi['data']=$this->prodi_model->get_paged_list()->result();

		$this->load->library('pagination');
		$config['uri_segment']=3;
		$this->pagination->initialize($config);
		
		if($this->uri->segment(3) == 'delete_success')
				$prodi['message'] = 'Data berhasil dihapus';
		else if($this->uri->segment(3) == 'add_success')
				$prodi['message'] = 'Data berhasil ditambah';
		else if($this->uri->segment(3) == 'update_success')
				$prodi['message'] = 'Data berhasil diedit';
		else
				$prodi['message'] =' ';
		$prodi['active'] = 'prodi';
		$this->load->view('templates/prodi',$prodi);

		}

		function add_prodi()
		{

		$data['active'] = 'prodi';
		$this->load->view('templates/insert_prodi', $data);
		
	
		}

		function insert_prodi(){
		$kd = $this->input->post('id_PS');
		$nama = $this->input->post('nama_PS');		

		$data = array(
			'id_PS' => $kd,
			'nama_PS' => $nama,
			);
		$this->prodi_model->save($data);
		redirect('tugas/prodi/add_success');
	}

	function delete_prodi($id) {
	//delete siswa
	$this->prodi_model->delete($id);

	/*echo "

<script>
function confirmDialog($nama) {
 return confirm('Apakah anda yakin akan menghapus data ini?')
}
</script>

";*/
	//redirect to dosen list page
	
	redirect('tugas/prodi/delete_success','refresh');
}

	function update_prodi($id)
		{
			$data['prodi']=$this->prodi_model->get_paged_list_update($id)->result();
			$data['active'] = 'prodi';
			$this->load->view('templates/edit_prodi',$data);

		}

	function update_pro()
		{
		$id = $this->input->post('id_PS');
		$nama = $this->input->post('nama_PS');

			
		$data = array(
			'id_PS' => $id,
			'nama_PS' => $nama
			);
	
		$this->prodi_model->update($id,$data);
		redirect ('tugas/prodi/update_success');
		}

	function assesment()
	{
		$this->load->view('templates/formulir_assesment');
	}

	function get_assesment($id_skripsi)
	{
		$id = $id_skripsi;

		$data['assesment'] = $this->formulir_model->get_assesment($id)->result();
		//var_dump($data['assesment']); die();

		$this->load->view('templates/formulir_assesment', $data);
	}

	function formulir()
	{
		$this->load->view('templates/formulir_list');
	}

	function get_formulir($id)
	{
		$data['id'] = $id;
		$this->load->view('templates/formulir_list', $data);
	}

	function login()
	{
		if(!$_POST)
		{

			$input = (object) $this->login->getDefaultValues();

		}
		else
		{

			$input = (object) $this->input->post();
		}

		if(!$this->login->validate()) {
			$this->load->view(('templates/loginFix'), compact('input'));
			return;
		}

		if(!$this->login->run($input)) {
			redirect('tugas/login');
		}
		else
		{
			if($_SESSION['level'] == '1')
			{ redirect('tugas/skripsi');}
			else
			{
				$id_user = $_SESSION['username'];
				$id = $this->formulir_model->search($id_user)->result();
				foreach($id as $d)
				{
					$id_new = $d->id_skripsi;
				}
				$session_data = [
						'id_skripsi' => $id_new
						];

					$this->session->set_userdata($session_data);
				
				redirect('tugas/get_formulir/'.$id_new);
			}
		}
	}

	public function gaji_dosen()
	{
		$dosen['active'] ='gaji';
		$dosen['gaji'] = $this->gaji_model->gaji()->result();
		if($this->uri->segment(3) == 'update_success')
				$dosen['message'] = 'Data berhasil diubah';
		$this->load->view('templates/gaji_dosen_seminar', $dosen);
	}

	public function update_gaji()
	{
		$pembimbing1 = $this->input->post('pembimbing1');
		$pembimbing2 = $this->input->post('pembimbing2');
		$pembanding1 = $this->input->post('pembanding1');
		$pembanding2 = $this->input->post('pembanding2');

		$data = array(
			'pembimbing1' => $pembimbing1,
			'pembimbing2' => $pembimbing2,
			'pembanding1' => $pembanding1,
			'pembanding2' => $pembanding2,
			);

		$this->gaji_model->save($data);
		redirect('tugas/gaji_dosen/update_success');

	}

	public function jadwal_seminar()
	{
		$data['active'] = 'jadwal seminar';
		$data['jadwal'] = $this->jadwal_model->show_jadwal()->result();

			if($this->uri->segment(3) == 'tanggal_tidak_valid')
				$data['message'] ='Tanggal Tidak Valid';
			else if($this->uri->segment(3) == 'sukses_menambah_jadwal_baru')
				$data['message'] ='Sukses Menambah Jadwal Baru';
			else if($this->uri->segment(3) == 'gagal_menambah_jadwal_baru')
				$data['message'] ='Gagal Menambah Jadwal Baru';
			else if($this->uri->segment(3) == 'delete_success')
				$data['message'] ='Berhasil Menghapus Data';
		$this->load->view('templates/jadwal_seminar', $data);
	}

	public function tambah_jadwal_baru()
	{
		$seminar = $this->input->post('seminar');
		$tanggal = $this->input->post('jadwal');

		$datetime2 = new DateTime($tanggal);
 		$datetime1 = new DateTime(date("Y-m-d"));
 		$interval = $datetime1->diff($datetime2);
 		echo $interval->format('%R%d days');

		if($interval->format('%R%d') < 0)
		{
			redirect('tugas/jadwal_seminar/tanggal_tidak_valid');
		}
		$batas = $this->input->post('batas');
		$status ='akan datang';

		$data = array(
			'seminar' => $seminar,
			'jadwal' => $tanggal,
			'batas_sidang' => $batas,
			'status' => $status
			);
		$saved = $this->jadwal_model->save($data);

		if($saved)
			{
				redirect('tugas/jadwal_seminar/sukses_menambah_jadwal_baru');
			}

		else
		{
			redirect('tugas/jadwal_seminar/gagal_menambah_jadwal_baru');
		}
		
	}

	function delete_jadwal($id) {
	//delete 
	$this->jadwal_model->delete($id);
	
	redirect('tugas/jadwal_seminar/delete_success','refresh');
}

	function edit_jadwal($id){
		$data['id'] = $id;
		$data['active'] ='jadwal seminar';
		$data['data'] = $this->jadwal_model->get_data_by_id($data['id'])->result();
		$data['dosen'] = $this->dosen_model->get_paged_list()->result();
		$data['total'] = $this->jadwal_model->get_mahasiswa($data['id'])->num_rows();
		$data['tgl'] = $this->jadwal_model->get_mahasiswa($data['id'])->result();
		$data['button_active'] = $this->getGlobal($id)['jumlah_mhs_sem'] <= $this->getGlobal($id)['batas_mhs_sem'];

		if($this->uri->segment(3) == 'update_success')
		{
			$data['message'] = 'Update Berhasil';
			echo "cek";die();
		}
		$this->load->view('templates/edit_jadwal',$data);


	}

	function update_jadwal($id)
	{
		$jadwal = $this->input->post('jadwal');
		$batas = $this->input->post('batas');
		$pembanding1 = $this->input->post('pembanding1');
		$pembanding2 = $this->input->post('pembanding2');
		$batas = (int) $batas;

		$data = array(
			'jadwal' => $jadwal,
			'batas_sidang' => $batas,
			'pembanding1' => $pembanding1,
			'pembanding2' => $pembanding2
			);

		$saved = $this->jadwal_model->update_seminar($data,$id);

		redirect('tugas/edit_jadwal/'.$id.'/update_success');
	}

	function delete_mahasiswa_sidang($nim,$id)
	{
		$data['delete'] = $this->jadwal_model->delete_mahasiswa_di_jadwal($nim,$id);

		redirect('tugas/edit_jadwal/'.$id);
	}

	function hapusLebih($id)
	{
		$isSaved = true;

		$post = $this->input->post();
		$batas = $this->getGlobal($id)['batas_mhs_sem'];
		$sisa = $this->getGlobal($id)['jumlah_mhs_sem'] - $batas;

		if($batas > 0 && $sisa > 0)
		{
			$ids = $this->db->query("SELECT id FROM mahasiswa_sidang LIMIT {$sisa}")->result();

			$ids = array_map(function($value) {
				return $value->id;
			}, $ids);

			if(count($ids) > 0)
			{
				$ids = implode(',', $ids);
				$query = "DELETE FROM mahasiswa_sidang WHERE id IN({$ids})";

				$this->db->query($query);
				$isSaved = $this->db->affected_rows() > 0;
			}
		}

		return $isSaved;
	}

	function add_mahasiswa($id)
	{
		if($this->getGlobal($id)['jumlah_mhs_sem'] >= $this->getGlobal($id)['batas_mhs_sem'])
		{
			redirect('tugas/edit_jadwal/'. $id);
		}

		$data = [];
		$post = $this->input->post();

		$data['banding'] = $this->jadwal_model->banding($id)->result();
		
		$existNim = array_flip(array_map(function($value) {
			return $value->nim;
		}, $data['banding']));

		if($post)
		{
			$nims = $post['mahasiswa'] ?: [];
			$isSaved = true;

			if($nims)
			{
				$queryVal = '';
				$idx = 0;
				$query = "INSERT INTO mahasiswa_sidang(id, id_jadwal_seminar, nim) ";

				foreach($nims as $nim)
				{
					if(!isset($existNim[$nim]))
					{
						$queryVal .= $idx > 0 ? "(NULL, {$id}, '{$nim}')," : "VALUES(NULL, {$id}, '{$nim}'),";
						$idx++;
					}
				}

				if($queryVal)
				{
					$query = $query . trim($queryVal, ', ');
					$this->db->query($query);
					$isSaved = $this->db->affected_rows() > 0;	
				}
			}

			if($isSaved)
			{
				redirect('tugas/edit_jadwal/' . $id);
			}
		}

		$data['id'] = $id;
		$id_b = (int) $data['id'];
		$query = "SELECT mahasiswa.nim,mahasiswa.nama FROM mahasiswa,skripsi WHERE mahasiswa.nim = skripsi.nim AND skripsi.status=(SELECT seminar FROM jadwal_seminar WHERE id=$id_b);";
	
		$data['pilih'] = $this->db->query($query)->result();

		return $this->load->view('templates/pilih_mahasiswa_sidang',$data);
	}

	function detail_jadwal($id)
	{
		$id = (int)$id;
		$query = "SELECT mahasiswa.nama FROM mahasiswa , mahasiswa_sidang WHERE mahasiswa_sidang.nim = mahasiswa.nim AND mahasiswa_sidang.id_jadwal_seminar = $id";

		$data['data'] = $this->db->query($query)->result();
		$data['total'] = $this->db->query($query)->num_rows();
		$this->load->view('templates/detail_jadwal', $data);
	} 
	public function logout()
	{
		$this->login->logout();
		redirect('tugas/login');
	} 

}